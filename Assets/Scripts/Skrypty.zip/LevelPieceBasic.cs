﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelPieceBasic : MonoBehaviour
{
    public Transform startPoint;
    public Transform exitPoint;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
